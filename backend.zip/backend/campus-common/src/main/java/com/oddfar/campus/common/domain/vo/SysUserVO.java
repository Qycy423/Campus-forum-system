package com.oddfar.campus.common.domain.vo;

import com.oddfar.campus.common.domain.PageParam;
import lombok.Data;
import lombok.EqualsAndHashCode;

/**
*
* @author 致远
*/
@Data
@EqualsAndHashCode(callSuper = true)
public class SysUserVO extends PageParam  {
	private static final long serialVersionUID = 1L;



}