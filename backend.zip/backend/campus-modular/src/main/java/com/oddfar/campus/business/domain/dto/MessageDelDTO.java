package com.oddfar.campus.business.domain.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @Author Yang
 * @Date 2024/5/29 20:23
 * @Description MessageDelDTO
 * @Version 1.0
 */


@Data
public class MessageDelDTO {

    @NotNull(message = "留言id不能为空")
    private long id;




}
