package com.oddfar.campus.business.service.impl;


import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.oddfar.campus.business.domain.entity.CampusNotice;
import com.oddfar.campus.business.domain.vo.ContentVo;
import com.oddfar.campus.business.service.CampusNoticeService;
import com.oddfar.campus.business.mapper.CampusNoticeMapper;
import com.oddfar.campus.common.core.page.PageUtils;
import com.oddfar.campus.common.domain.PageResult;
import org.springframework.stereotype.Service;

import java.util.List;

/**
* @author admin
* @description 针对表【campus_notice】的数据库操作Service实现
* @createDate 2024-05-29 17:53:55
*/
@Service
public class CampusNoticeServiceImpl extends ServiceImpl<CampusNoticeMapper, CampusNotice>
implements CampusNoticeService{

}
