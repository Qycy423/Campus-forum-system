package com.oddfar.campus.business.domain.vo;

import lombok.Data;
import lombok.experimental.Accessors;

import java.util.Date;

/**
 * @Author Yang
 * @Date 2024/5/29 18:15
 * @Description NoticeVo
 * @Version 1.0
 */

@Data
@Accessors(chain = true)
public class NoticeVo {

    /**
     * 公告id
     */
    private Long noticeId;

    /**
     * 通过标题
     */
    private String title;

    /**
     * 内容
     */
    private String content;

    /**
     * 创建时间
     */
    private String createTime;

    /**
     * 发布者id
     */
    private Long createUser;

    /**
     * 更新时间
     */
    private String updateTime;

    /**
     * 更新人
     */
    private Long updateUser;


    private String userName;



}
