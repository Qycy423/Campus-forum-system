package com.oddfar.campus.business.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.oddfar.campus.business.domain.entity.CampusMessage;


/**
* @author admin
* @description 针对表【campus_message】的数据库操作Service
* @createDate 2024-05-29 17:53:55
*/
public interface CampusMessageService extends IService<CampusMessage> {

}
