package com.oddfar.campus.business.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.oddfar.campus.business.domain.entity.CampusNotice;

/**
* @author admin
* @description 针对表【campus_notice】的数据库操作Service
* @createDate 2024-05-29 17:53:55
*/
public interface CampusNoticeService extends IService<CampusNotice> {

}
