package com.oddfar.campus.business.controller.web;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.oddfar.campus.business.domain.dto.MessageAddDTO;
import com.oddfar.campus.business.domain.dto.MessageDelDTO;
import com.oddfar.campus.business.domain.dto.NoticeDelDTO;
import com.oddfar.campus.business.domain.entity.CampusMessage;
import com.oddfar.campus.business.domain.entity.CampusNotice;
import com.oddfar.campus.business.service.CampusMessageService;
import com.oddfar.campus.common.annotation.Anonymous;
import com.oddfar.campus.common.annotation.ApiResource;
import com.oddfar.campus.common.core.page.PageUtils;
import com.oddfar.campus.common.domain.R;
import com.oddfar.campus.common.enums.ResBizTypeEnum;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * @Author Yang
 * @Date 2024/5/29 20:00
 * @Description CampusMessageController
 * @Version 1.0
 */

@RestController
@RequestMapping("/campus")
@ApiResource(name = "校园墙信息api", appCode = "campus", resBizType = ResBizTypeEnum.BUSINESS)
public class CampusMessageController {

    @Autowired
    private CampusMessageService campusMessageService;

    @Anonymous
    @GetMapping(value = "/messageAllList/{pageNo}/{pageSize}", name = "查询分类分页列表")
    public R messagePageList(@PathVariable int pageNo, @PathVariable int pageSize) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年M月d日 ahh点mm分");
        Page<CampusMessage> objectPage = new Page<>(pageNo,pageSize);


        Page<CampusMessage> page = campusMessageService.page(objectPage,new LambdaQueryWrapper<>(CampusMessage.class
        ).orderByDesc(CampusMessage::getCreateTime));

        for (CampusMessage record : page.getRecords()) {
            record.setCreateDateTime(sdf.format(record.getCreateTime()));
        }

        return R.ok().setData(page);

    }

    @Anonymous
    @GetMapping(value = "/message/{userId}", name = "用户查看个人留言")
    public R userMessageList(@PathVariable long userId) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年M月d日 ahh点mm分");
        List<CampusMessage> list = this.campusMessageService.list(
                new LambdaQueryWrapper<>(CampusMessage.class)
                        .eq(CampusMessage::getCreateUser, userId)
                        .orderByDesc(CampusMessage::getCreateTime)
        );

        for (CampusMessage record : list) {
            record.setCreateDateTime(sdf.format(record.getCreateTime()));
        }

        return R.ok().setData(list);
    }


    @Anonymous
    @PostMapping(value = "/delMessage", name = "删除留言")
    public R messageDel(@Validated @RequestBody MessageDelDTO dto) {

        boolean b = this.campusMessageService.removeById(dto.getId());
        return R.ok();
    }




    @Anonymous
    @PostMapping(value = "/addMessage", name = "添加留言")
    public R messageAdd(@Validated @RequestBody MessageAddDTO dto) {

        CampusMessage value = new CampusMessage();
        value.setContent(dto.getContent());
        value.setCreateUser(dto.getUserId());
        value.setCreateTime(new Date());

        boolean save = this.campusMessageService.save(value);

        return R.ok();
    }






}
