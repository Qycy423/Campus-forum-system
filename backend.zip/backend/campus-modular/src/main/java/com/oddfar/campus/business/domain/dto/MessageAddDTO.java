package com.oddfar.campus.business.domain.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Date;

/**
 * @Author Yang
 * @Date 2024/5/29 20:52
 * @Description MessageAddDTO
 * @Version 1.0
 */

@Data
public class MessageAddDTO {



    /**
     * 留言内容
     */
    @NotBlank(message = "留言内容不能为空")
    private String content;


    /**
     * 创建人
     */
    @NotNull(message = "用户id不能为空")
    private Long userId;



}
