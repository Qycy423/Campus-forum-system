package com.oddfar.campus.business.domain.dto;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @Author Yang
 * @Date 2024/5/29 19:19
 * @Description NoticeUpdateDTO
 * @Version 1.0
 */
@Data
public class NoticeUpdateDTO {

    @NotNull(message = "公告id不能为空")
    private long noticeId;

    private long userId;

    @NotBlank(message = "公告标题不能为空")
    private String title;

    @NotBlank(message = "公告标题不能为空")
    private String content;


}
