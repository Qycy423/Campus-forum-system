package com.oddfar.campus.business.controller.web;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.github.pagehelper.IPage;
import com.oddfar.campus.business.domain.dto.NoticeAddDTO;
import com.oddfar.campus.business.domain.dto.NoticeDelDTO;
import com.oddfar.campus.business.domain.dto.NoticeUpdateDTO;
import com.oddfar.campus.business.domain.entity.CampusNotice;
import com.oddfar.campus.business.domain.entity.CategoryEntity;
import com.oddfar.campus.business.domain.vo.ContentVo;
import com.oddfar.campus.business.domain.vo.NoticeVo;
import com.oddfar.campus.business.domain.vo.ToCommentVo;
import com.oddfar.campus.business.service.impl.CampusNoticeServiceImpl;
import com.oddfar.campus.common.annotation.Anonymous;
import com.oddfar.campus.common.annotation.ApiResource;
import com.oddfar.campus.common.core.page.PageUtils;
import com.oddfar.campus.common.domain.PageResult;
import com.oddfar.campus.common.domain.R;
import com.oddfar.campus.common.enums.ResBizTypeEnum;
import com.oddfar.campus.common.utils.StringUtils;
import com.oddfar.campus.framework.service.impl.SysUserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlReturnResultSet;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @Author Yang
 * @Date 2024/5/29 17:56
 * @Description CampusNoticController
 * @Version 1.0
 */
@RestController
@RequestMapping("/campus")
@ApiResource(name = "校园墙信息api", appCode = "campus", resBizType = ResBizTypeEnum.BUSINESS)
public class CampusNoticeController {

    @Autowired
    private CampusNoticeServiceImpl campusNoticeService;


    @Autowired
    private SysUserServiceImpl sysUserService;

    @Anonymous
    @GetMapping(value = "/noticeList", name = "查询分类列表")
    public R noticeList() {
        // 展示最新5个公告

        List<CampusNotice> list = this.campusNoticeService.list(
                new LambdaQueryWrapper<>(CampusNotice.class)
                        .orderByDesc(CampusNotice::getCreateTime)
                        .last("limit 5")
        );

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy年M月d日 ahh:mm");
        List<NoticeVo> collect = list.stream().map(item -> {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy年M月d日 ahh点mm分");
            NoticeVo no = new NoticeVo();
            no
                    .setNoticeId(item.getNoticeId())
                    .setTitle(item.getTitle())
                    .setContent(item.getContent())
                    .setCreateTime(sdf.format(item.getCreateTime()))
                    .setUserName("管理员");

            return no;
        }).collect(Collectors.toList());

        return R.ok().put("data",collect);
    }




    @Anonymous
    @GetMapping(value = "/noticeAllList/{pageNo}/{pageSize}", name = "查询分类分页列表")
    public R noticePageList(@PathVariable int pageNo,@PathVariable int pageSize) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy年M月d日 ahh点mm分");
        Page<CampusNotice> objectPage = new Page<>(pageNo,pageSize);

        Page<CampusNotice> page = campusNoticeService.page(objectPage,new LambdaQueryWrapper<>(CampusNotice.class)
                .orderByDesc(CampusNotice::getCreateTime));

        for (CampusNotice record : page.getRecords()) {
            record.setCreateDateTime(sdf.format(record.getCreateTime()));
        }



        return R.ok().setData(page);
    }


    @Anonymous
    @PostMapping(value = "/addNotice", name = "添加公告")
    public R noticeAdd(@Validated @RequestBody NoticeAddDTO dto) {

        // dto
        CampusNotice campusNotice = new CampusNotice();

        campusNotice.setContent(dto.getContent());
        campusNotice.setTitle(dto.getTitle());
        campusNotice.setCreateUser(dto.getUserId());
        campusNotice.setCreateTime(new Date());
        campusNotice.setUpdateTime(new Date());

        boolean save = this.campusNoticeService.save(campusNotice);

        return R.ok();
    }

    @Anonymous
    @PostMapping(value = "/updateNotice", name = "修改公告")
    public R noticeUpdate(@Validated @RequestBody NoticeUpdateDTO dto) {

        // 获取公告
        CampusNotice campusNotice = this.campusNoticeService.getOne(
                new LambdaQueryWrapper<>(CampusNotice.class)
                        .eq(CampusNotice::getNoticeId,dto.getNoticeId())
        );


        // 检查公告是否存在
        if (campusNotice == null)
            return R.error("公告不存在");


        campusNotice.setTitle(dto.getTitle());
        campusNotice.setContent(dto.getContent());
        campusNotice.setUpdateUser(dto.getUserId());
        campusNotice.setUpdateTime(new Date());

        boolean b = this.campusNoticeService.updateById(campusNotice);

        return R.ok();
    }


    @Anonymous
    @PostMapping(value = "/delNotice", name = "删除公告")
    public R noticeDel(@Validated @RequestBody NoticeDelDTO dto) {
        boolean b = this.campusNoticeService.removeById(dto.getId());
        return R.ok();
    }






}
