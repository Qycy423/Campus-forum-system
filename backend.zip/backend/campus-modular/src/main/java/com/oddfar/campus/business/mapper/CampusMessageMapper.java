package com.oddfar.campus.business.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.oddfar.campus.business.domain.entity.CampusMessage;


/**
* @author admin
* @description 针对表【campus_message】的数据库操作Mapper
* @createDate 2024-05-29 17:53:55
* @Entity generator.domain.CampusMessage
*/
public interface CampusMessageMapper extends BaseMapper<CampusMessage> {


}
