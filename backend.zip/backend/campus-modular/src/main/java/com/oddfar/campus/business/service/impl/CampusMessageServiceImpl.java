package com.oddfar.campus.business.service.impl;



import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;
import com.oddfar.campus.business.domain.entity.CampusMessage;
import com.oddfar.campus.business.service.CampusMessageService;
import com.oddfar.campus.business.mapper.CampusMessageMapper;
import org.springframework.stereotype.Service;

/**
* @author admin
* @description 针对表【campus_message】的数据库操作Service实现
* @createDate 2024-05-29 17:53:55
*/
@Service
public class CampusMessageServiceImpl extends ServiceImpl<CampusMessageMapper, CampusMessage>
implements CampusMessageService{

}
