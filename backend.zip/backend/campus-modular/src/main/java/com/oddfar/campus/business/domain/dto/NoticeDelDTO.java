package com.oddfar.campus.business.domain.dto;

import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @Author Yang
 * @Date 2024/5/29 19:25
 * @Description NoticeDelDTO
 * @Version 1.0
 */

@Data
public class NoticeDelDTO {

    @NotNull(message = "公告id不能为空")
    private long id;


}
